#include "stm32f10x.h"                  // Device header
#include "Serial.h"
#include "MyHMC5883L.h"
#include "Servo.h"
#include "stdint.h"
#include "Delay.h"
#include "math.h"



int main()
{

	int16_t  X , Y , Z;
	int16_t  x , y , z;
	int Angle;
	double ArcTan;
	
	HMC5883L_Init();
	Serial_Init();
	Servo_Init();
	
	
	while (1)
	{
		
		HMC5883L_GetData(&X,&Y,&Z);
		
		x = EMA(X,x);
		y = EMA(Y,y);
		z = EMA(Z,z);
		
	
		ArcTan = (double)y / (double)x;
		Angle = atan(ArcTan)*57.3 + 90;
		
		Serial_SendNumber(Angle, 3);
		
		Servo_SetAngle(Angle);
		
		Delay_ms(20);
		
	}
}


		
