#include "stm32f10x.h"                  // Device header
#include "PWM.h"

/**
  * 函    数：舵机初始化
  * 参    数：无
  * 返 回 值：无
  * 注意事项：无
  */
void Servo_Init(void)
{
	PWM_Init();
}

/**
  * 函    数：舵机角度
  * 参    数：Angle 角度
  * 返 回 值：无
  * 注意事项：无
  */
void Servo_SetAngle(float Angle)
{
	PWM_SetCompare2(Angle / 180 * 2000 + 500);
}
