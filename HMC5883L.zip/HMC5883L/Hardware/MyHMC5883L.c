#include "stm32f10x.h"                  // Device header
#include "MyI2C.h"
#include "MyHMC5883L.h"

#define alpha 0.2

/**
  * 函    数：HMC5883L写
  * 参    数：RegAddress地址信息
  * 返 回 值：无
  * 注意事项：无
  */
void HMC5883L_WriteReg(uint8_t RegAddress, uint8_t Data)
{
	MyI2C_Start();						
	MyI2C_SendByte(HMC5883L_WRITE_ADDRESS);	
	MyI2C_ReceiveAck();					
	MyI2C_SendByte(RegAddress);		
	MyI2C_ReceiveAck();					
	MyI2C_SendByte(Data);			
	MyI2C_ReceiveAck();				
	MyI2C_Stop();					
}

/**
  * 函    数：HMC5883L读
  * 参    数：RegAddress地址信息
  * 返 回 值：无
  * 注意事项：无
  */
uint8_t HMC5883L_ReadReg(uint8_t RegAddress)
{
	uint8_t Data;
	
	MyI2C_Start();						
	MyI2C_SendByte(HMC5883L_WRITE_ADDRESS);	
	MyI2C_ReceiveAck();					
	MyI2C_SendByte(RegAddress);			
	MyI2C_ReceiveAck();				
	
	MyI2C_Start();					
	MyI2C_SendByte(HMC5883L_READ_ADDRESS | 0x01);
	MyI2C_ReceiveAck();				
	Data = MyI2C_ReceiveByte();		
	MyI2C_SendAck(1);			
	MyI2C_Stop();	
	
	return Data;
}

/**
  * 函    数：HMC5883L初始化
  * 参    数：无
  * 返 回 值：无
  * 注意事项：无
  */
void HMC5883L_Init(void)
{
	MyI2C_Init();
	HMC5883L_WriteReg(HMC5883L_REG_CONFIG_A, 0X70);
	HMC5883L_WriteReg(HMC5883L_REG_CONFIG_B, 0X20);
	HMC5883L_WriteReg(HMC5883L_REG_MODE, 0X00);
}

/**
  * 函    数：HMC5883L输出数据
  * 参    数：各磁场强度
  * 返 回 值：无
  * 注意事项：无
  */
void HMC5883L_GetData(int16_t *GaX, int16_t *GaY, int16_t *GaZ)
{
	uint8_t DataH, DataL;								
	
	DataH = HMC5883L_ReadReg(HMC5883L_REG_OUT_X_M);		
	DataL = HMC5883L_ReadReg(HMC5883L_REG_OUT_X_L);		
	*GaX = (DataH << 8) | DataL;						
	
	DataH = HMC5883L_ReadReg(HMC5883L_REG_OUT_Z_M);		
	DataL = HMC5883L_ReadReg(HMC5883L_REG_OUT_Z_L);		
	*GaY = (DataH << 8) | DataL;						
	
	DataH = HMC5883L_ReadReg(HMC5883L_REG_OUT_Y_M);		
	DataL = HMC5883L_ReadReg(HMC5883L_REG_OUT_Y_L);		
	*GaZ = (DataH << 8) | DataL;						
}

/**
  * 函    数：处理和过滤磁力数据
  * 参    数：rawValue 最新的未处理的数据; filteredValue 前一次EMA计算的结果
  * 返 回 值：无
  * 注意事项：无
  */
float EMA(float rawValue, float filteredValue)
{
    return alpha * rawValue + (1 - alpha) * filteredValue;
}







